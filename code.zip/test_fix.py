#!/usr/bin/env python3
"""
Test script to verify the markdown bold formatting fix for headings
"""

import re

def _strip_markdown_formatting(text):
    """Strip markdown formatting syntax (bold, italic) from text"""
    # Remove **bold** and __bold__
    text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)
    text = re.sub(r'__(.*?)__', r'\1', text)
    # Remove *italic* and _italic_ (single underscore/asterisk)
    text = re.sub(r'\*(.*?)\*', r'\1', text)
    text = re.sub(r'_(.*?)_', r'\1', text)
    return text

# Test cases from the user's markdown
test_cases = [
    "**1. Objective**",
    "**2. Study Overview**",
    "**3. Study Flowchart**",
    "**4. Study Steps**",
    "**5. Safety Monitoring**",
    "**Study Phase**",
    "**Protocol Approval**",
]

print("Testing markdown formatting removal from headings:")
print("=" * 60)

for test in test_cases:
    result = _strip_markdown_formatting(test)
    print(f"Input:  {test}")
    print(f"Output: {result}")
    assert "**" not in result, f"Failed to remove ** from {test}"
    print("✓ PASS")
    print()

print("=" * 60)
print("All tests passed! The fix correctly strips ** from headings.")
