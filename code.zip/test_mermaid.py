#!/usr/bin/env python3
"""
Test script to verify mermaid rendering works in both PDF and DOCX
"""
import requests
import json

# Test JSON with mermaid diagram
test_data = {
    "markdown": """# 🧪 Clinical Protocol: Phase II Trial – Efficacy and Safety of Drug XYZ in Type 2 Diabetes

## **1. Objective**
To evaluate the **efficacy and safety** of **Drug XYZ** compared to **Placebo** in adults diagnosed with **Type 2 Diabetes Mellitus (T2DM)**.

---

## **2. Study Overview**

| Parameter | Description |
|------------|--------------|
| **Study Phase** | Phase II |
| **Design** | Randomized, Double-Blind, Placebo-Controlled |
| **Population** | Adults Age 18-65 with Type 2 Diabetes |
| **Duration** | 12 Weeks |
| **Primary Endpoint** | Change in HbA1c from baseline to Week 12 |
| **Secondary Endpoints** | Fasting Plasma Glucose, Safety Profile, Adverse Events |
| **Treatment Arms** | Drug XYZ Low Dose, Drug XYZ High Dose, Placebo |

---

## **3. Study Flowchart**

```mermaid
flowchart TD
    A[Start Protocol Approval] --> B[Site Selection and Investigator Training]
    B --> C[Patient Screening]
    C --> D{Eligibility Check}
    D -->|Eligible| E[Informed Consent]
    D -->|Not Eligible| F[Screen Failure Log]

    E --> G[Randomization 1-1-1]
    G --> H1[Arm 1 Drug XYZ Low Dose]
    G --> H2[Arm 2 Drug XYZ High Dose]
    G --> H3[Arm 3 Placebo]

    H1 --> I[12-Week Treatment Period]
    H2 --> I
    H3 --> I

    I --> J[Follow-Up Week 4, 8, 12]
    J --> K[Safety and Efficacy Evaluation]
    K --> L{Meets Study Endpoints?}

    L -->|Yes| M[Proceed to Phase III]
    L -->|No| N[Amendment or Termination]
    M --> O[End of Study Report]
    N --> O
    F --> O
```

---

## **4. Study Steps**

1. **Protocol Approval** – Obtain ethics and regulatory clearance (IRB, FDA, etc.).
2. **Site Selection** – Identify qualified clinical sites and conduct investigator training.
3. **Patient Screening** – Evaluate participants based on inclusion/exclusion criteria.
4. **Informed Consent** – Obtain signed consent prior to enrollment.
5. **Randomization** – Randomly assign participants to one of three study arms.
6. **Treatment Period (12 Weeks)** – Administer Drug XYZ or Placebo as per assignment.
7. **Assessments** – Conduct follow-ups at Week 4, 8, and 12 for safety and efficacy.
8. **Data Collection** – Record data in electronic CRFs (eCRFs) and report AEs promptly.
9. **Evaluation** – Perform interim and final analyses on primary and secondary endpoints.
10. **Decision Point** – Determine progression to Phase III or amend/terminate protocol.
11. **Final Report** – Summarize findings and submit to regulatory authorities.

---

## **5. Safety Monitoring**

- **Adverse Event Reporting:** Continuous throughout study.
- **Data Safety Monitoring Board (DSMB):** Independent review at mid-study.
- **Early Termination Criteria:** Significant safety concerns or lack of efficacy.""",
    "filename": "Clinical_Protocol_Corrected"
}

def test_pdf():
    """Test PDF generation with mermaid"""
    print("\n" + "="*80)
    print("Testing PDF generation with mermaid diagram...")
    print("="*80)

    try:
        response = requests.post(
            "http://localhost:8000/render/pdf",
            json=test_data,
            timeout=60
        )

        if response.status_code == 200:
            # Save PDF
            with open("test_output.pdf", "wb") as f:
                f.write(response.content)
            print("✓ PDF generated successfully: test_output.pdf")
            print(f"  File size: {len(response.content)} bytes")
            return True
        else:
            print(f"✗ PDF generation failed with status {response.status_code}")
            print(f"  Response: {response.text}")
            return False
    except Exception as e:
        print(f"✗ Error testing PDF: {e}")
        return False

def test_docx():
    """Test DOCX generation with mermaid"""
    print("\n" + "="*80)
    print("Testing DOCX generation with mermaid diagram...")
    print("="*80)

    try:
        response = requests.post(
            "http://localhost:8000/render/docx",
            json=test_data,
            timeout=60
        )

        if response.status_code == 200:
            # Save DOCX
            with open("test_output.docx", "wb") as f:
                f.write(response.content)
            print("✓ DOCX generated successfully: test_output.docx")
            print(f"  File size: {len(response.content)} bytes")
            return True
        else:
            print(f"✗ DOCX generation failed with status {response.status_code}")
            print(f"  Response: {response.text}")
            return False
    except Exception as e:
        print(f"✗ Error testing DOCX: {e}")
        return False

if __name__ == "__main__":
    print("\n" + "="*80)
    print("Mermaid Rendering Test Suite")
    print("="*80)
    print("\nThis test will verify that:")
    print("1. Mermaid diagrams are rendered locally using mmdc")
    print("2. No external APIs (kroki.io, mermaid.ink) are used")
    print("3. Diagrams appear correctly in both PDF and DOCX outputs")
    print("\nMake sure the API server is running on http://localhost:8000")
    print("="*80)

    pdf_ok = test_pdf()
    docx_ok = test_docx()

    print("\n" + "="*80)
    print("Test Results Summary")
    print("="*80)
    print(f"PDF:  {'✓ PASS' if pdf_ok else '✗ FAIL'}")
    print(f"DOCX: {'✓ PASS' if docx_ok else '✗ FAIL'}")

    if pdf_ok and docx_ok:
        print("\n✓ All tests passed! Mermaid rendering is working correctly.")
        print("\nGenerated files:")
        print("  - test_output.pdf")
        print("  - test_output.docx")
    else:
        print("\n✗ Some tests failed. Check the logs above for details.")

    print("="*80)
