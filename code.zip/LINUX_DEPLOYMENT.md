# Linux Server Deployment Guide

This guide covers deploying the DOCX_PDF_API with high-resolution Mermaid support on Linux servers.

## Quick Start (Ubuntu/Debian)

### Option 1: Automated Installation Script
```bash
# Download and run the installation script
curl -O https://raw.githubusercontent.com/your-repo/DOCX_PDF_API/main/install_linux.sh
chmod +x install_linux.sh
./install_linux.sh
```

### Option 2: Manual Installation
```bash
# Update system
sudo apt-get update
sudo apt-get install -y python3-pip python3-venv build-essential

# Install Cairo system dependencies
sudo apt-get install -y libcairo2-dev libpango1.0-dev libgdk-pixbuf2.0-dev libffi-dev shared-mime-info

# Install WeasyPrint dependencies (optional)
sudo apt-get install -y libpango1.0-0 libharfbuzz0b libpangoft2-1.0-0

# Install Pandoc
sudo apt-get install -y pandoc

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install Python dependencies
pip install -r requirements.txt
```

## CentOS/RHEL Installation

```bash
# Update system
sudo yum update -y
sudo yum install -y python3-pip python3-venv gcc gcc-c++ make

# Install Cairo system dependencies
sudo yum install -y cairo-devel pango-devel gdk-pixbuf2-devel libffi-devel

# Install WeasyPrint dependencies (optional)
sudo yum install -y pango harfbuzz

# Install Pandoc
sudo yum install -y pandoc

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install Python dependencies
pip install -r requirements.txt
```

## Fedora Installation

```bash
# Update system
sudo dnf update -y
sudo dnf install -y python3-pip python3-venv gcc gcc-c++ make

# Install Cairo system dependencies
sudo dnf install -y cairo-devel pango-devel gdk-pixbuf2-devel libffi-devel

# Install WeasyPrint dependencies (optional)
sudo dnf install -y pango harfbuzz

# Install Pandoc
sudo dnf install -y pandoc

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install Python dependencies
pip install -r requirements.txt
```

## Docker Deployment

### Using Docker Compose (Recommended)
```bash
# Build and start the service
docker-compose up -d

# View logs
docker-compose logs -f

# Stop the service
docker-compose down
```

### Using Docker directly
```bash
# Build the image
docker build -t docx-pdf-api .

# Run the container
docker run -d -p 8000:8000 --name docx-pdf-api docx-pdf-api

# View logs
docker logs -f docx-pdf-api

# Stop the container
docker stop docx-pdf-api
docker rm docx-pdf-api
```

## Production Deployment

### Using systemd (Recommended for production)

1. Create a systemd service file:
```bash
sudo nano /etc/systemd/system/docx-pdf-api.service
```

2. Add the following content:
```ini
[Unit]
Description=DOCX PDF API Service
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/path/to/DOCX_PDF_API
Environment=PATH=/path/to/DOCX_PDF_API/venv/bin
ExecStart=/path/to/DOCX_PDF_API/venv/bin/python -m uvicorn api:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

3. Enable and start the service:
```bash
sudo systemctl daemon-reload
sudo systemctl enable docx-pdf-api
sudo systemctl start docx-pdf-api
sudo systemctl status docx-pdf-api
```

### Using Nginx as reverse proxy

1. Install Nginx:
```bash
sudo apt-get install nginx
```

2. Create Nginx configuration:
```bash
sudo nano /etc/nginx/sites-available/docx-pdf-api
```

3. Add the following content:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Increase timeout for large file processing
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }
}
```

4. Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/docx-pdf-api /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## Testing the Installation

### Test Cairo installation:
```bash
python3 -c "
import cairosvg
import cairocffi
print('✓ Cairo libraries working correctly')
"
```

### Test the API:
```bash
# Start the server
source venv/bin/activate
python -m uvicorn api:app --host 0.0.0.0 --port 8000

# Test in another terminal
curl -X POST "http://localhost:8000/render/pdf" \
  -H "Content-Type: application/json" \
  -d '{
    "markdown": "```mermaid\nflowchart TD\n    A[Start] --> B[End]\n```",
    "filename": "test"
  }' \
  --output test.pdf
```

## Troubleshooting

### Common Issues:

1. **Cairo library not found**:
   ```bash
   # Ubuntu/Debian
   sudo apt-get install libcairo2-dev libpango1.0-dev libgdk-pixbuf2.0-dev libffi-dev
   
   # CentOS/RHEL
   sudo yum install cairo-devel pango-devel gdk-pixbuf2-devel libffi-devel
   ```

2. **Pandoc not found**:
   ```bash
   # Ubuntu/Debian
   sudo apt-get install pandoc
   
   # CentOS/RHEL
   sudo yum install pandoc
   ```

3. **Permission denied**:
   ```bash
   # Make sure the user has proper permissions
   sudo chown -R $USER:$USER /path/to/DOCX_PDF_API
   ```

4. **Port already in use**:
   ```bash
   # Find process using port 8000
   sudo lsof -i :8000
   
   # Kill the process
   sudo kill -9 <PID>
   ```

### Performance Optimization:

1. **Increase file upload limits** in Nginx:
   ```nginx
   client_max_body_size 50M;
   ```

2. **Enable gzip compression**:
   ```nginx
   gzip on;
   gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
   ```

3. **Set proper timeouts**:
   ```nginx
   proxy_read_timeout 300s;
   proxy_connect_timeout 75s;
   ```

## Security Considerations

1. **Use HTTPS in production**:
   ```bash
   # Install Certbot for Let's Encrypt
   sudo apt-get install certbot python3-certbot-nginx
   
   # Get SSL certificate
   sudo certbot --nginx -d your-domain.com
   ```

2. **Firewall configuration**:
   ```bash
   # Allow only necessary ports
   sudo ufw allow 22    # SSH
   sudo ufw allow 80   # HTTP
   sudo ufw allow 443  # HTTPS
   sudo ufw enable
   ```

3. **Regular updates**:
   ```bash
   # Update system packages
   sudo apt-get update && sudo apt-get upgrade
   
   # Update Python packages
   pip install --upgrade -r requirements.txt
   ```

## Monitoring

### Log monitoring:
```bash
# View application logs
journalctl -u docx-pdf-api -f

# View Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

### Health checks:
```bash
# Check service status
curl http://localhost:8000/health

# Check system resources
htop
df -h
free -h
```

This deployment guide ensures your DOCX_PDF_API with high-resolution Mermaid support works reliably on Linux servers.
