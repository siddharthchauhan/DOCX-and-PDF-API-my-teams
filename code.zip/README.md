# DOCX PDF API with High-Resolution Mermaid Support

A FastAPI-based service that converts Markdown documents to PDF and DOCX formats with high-resolution Mermaid diagram rendering.

## Features

- **High-Resolution Mermaid Diagrams**: Renders Mermaid diagrams at 1600x1200 resolution with 300 DPI for crisp, readable text
- **PDF Generation**: Supports both WeasyPrint and ReportLab backends
- **DOCX Generation**: Supports both Pandoc and python-docx backends
- **Syntax Highlighting**: Code blocks with syntax highlighting
- **Linux Compatible**: Full support for Ubuntu, CentOS, RHEL, and Fedora
- **Docker Support**: Ready-to-use Docker configuration
- **Health Monitoring**: Built-in health checks and system monitoring

## Quick Start

### Option 1: Docker (Recommended)
```bash
# Clone the repository
git clone <your-repo-url>
cd DOCX_PDF_API

# Build and start with Docker Compose
docker-compose up -d

# Test the API
curl http://localhost:8000/health
```

### Option 2: Manual Installation
```bash
# Run the automated installation script
chmod +x install_linux.sh
./install_linux.sh

# Start the server
source venv/bin/activate
python -m uvicorn api:app --host 0.0.0.0 --port 8000
```

## API Endpoints

- `POST /render/pdf` - Convert Markdown to PDF
- `POST /render/docx` - Convert Markdown to DOCX
- `POST /render/pdf-raw` - Convert Markdown to PDF (handles control characters)
- `POST /render/docx-raw` - Convert Markdown to DOCX (handles control characters)
- `GET /health` - Health check and system status
- `GET /docs` - Interactive API documentation

## Request Format

```json
{
  "markdown": "Your markdown content here",
  "filename": "output_filename",
  "css": "Optional custom CSS"
}
```

## High-Resolution Mermaid Support

The API automatically renders Mermaid diagrams at high resolution:

- **Resolution**: 1600x1200 pixels
- **DPI**: 300 DPI for crisp text
- **Format**: PNG with high-quality scaling
- **Fallback**: Multiple rendering methods ensure compatibility

### Example Mermaid Diagram

```markdown
```mermaid
flowchart TD
    A[Start] --> B{Is it raining?}
    B -->|Yes| C[Take umbrella]
    B -->|No| D[Check forecast]
    D --> E{Will it rain later?}
    E -->|Yes| C
    E -->|No| F[No umbrella needed]
    C --> G[Leave house]
    F --> G
    G --> H[Arrive at destination]
    H --> I[End]
    
    style A fill:#e1f5e1
    style I fill:#ffe1e1
    style B fill:#fff4e1
    style E fill:#fff4e1
```
```

## Linux Compatibility

### Supported Distributions
- Ubuntu 18.04+
- Debian 10+
- CentOS 7+
- RHEL 7+
- Fedora 30+

### System Dependencies

#### Ubuntu/Debian
```bash
sudo apt-get update
sudo apt-get install -y python3-pip python3-venv build-essential
sudo apt-get install -y libcairo2-dev libpango1.0-dev libgdk-pixbuf2.0-dev libffi-dev
sudo apt-get install -y pandoc
```

#### CentOS/RHEL
```bash
sudo yum update -y
sudo yum install -y python3-pip python3-venv gcc gcc-c++ make
sudo yum install -y cairo-devel pango-devel gdk-pixbuf2-devel libffi-devel
sudo yum install -y pandoc
```

#### Fedora
```bash
sudo dnf update -y
sudo dnf install -y python3-pip python3-venv gcc gcc-c++ make
sudo dnf install -y cairo-devel pango-devel gdk-pixbuf2-devel libffi-devel
sudo dnf install -y pandoc
```

## Testing

### Compatibility Test
```bash
python test_linux_compatibility.py
```

### Manual Testing
```bash
# Test PDF generation
curl -X POST "http://localhost:8000/render/pdf" \
  -H "Content-Type: application/json" \
  -d '{
    "markdown": "```mermaid\nflowchart TD\n    A[Start] --> B[End]\n```",
    "filename": "test"
  }' \
  --output test.pdf

# Test DOCX generation
curl -X POST "http://localhost:8000/render/docx" \
  -H "Content-Type: application/json" \
  -d '{
    "markdown": "```mermaid\nflowchart TD\n    A[Start] --> B[End]\n```",
    "filename": "test"
  }' \
  --output test.docx
```

## Production Deployment

### Using systemd
```bash
# Create service file
sudo nano /etc/systemd/system/docx-pdf-api.service

# Add service configuration
[Unit]
Description=DOCX PDF API Service
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/path/to/DOCX_PDF_API
Environment=PATH=/path/to/DOCX_PDF_API/venv/bin
ExecStart=/path/to/DOCX_PDF_API/venv/bin/python -m uvicorn api:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target

# Enable and start
sudo systemctl daemon-reload
sudo systemctl enable docx-pdf-api
sudo systemctl start docx-pdf-api
```

### Using Nginx
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Increase timeout for large file processing
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }
}
```

## Docker Configuration

### Dockerfile
The included Dockerfile creates a production-ready container with:
- Python 3.11 slim base image
- All system dependencies pre-installed
- Non-root user for security
- Health checks enabled
- Optimized for Linux deployment

### Docker Compose
```yaml
version: '3.8'

services:
  docx-pdf-api:
    build: .
    ports:
      - "8000:8000"
    environment:
      - PYTHONUNBUFFERED=1
    volumes:
      - ./logs:/app/logs
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s
```

## Monitoring

### Health Check
```bash
curl http://localhost:8000/health
```

Response includes:
- System status
- CPU and memory usage
- Feature availability
- Dependency status
- Mermaid rendering test results

### Logs
```bash
# Docker logs
docker-compose logs -f

# Systemd logs
journalctl -u docx-pdf-api -f

# Nginx logs
sudo tail -f /var/log/nginx/access.log
```

## Troubleshooting

### Common Issues

1. **Cairo library not found**
   ```bash
   # Ubuntu/Debian
   sudo apt-get install libcairo2-dev libpango1.0-dev libgdk-pixbuf2.0-dev libffi-dev
   
   # CentOS/RHEL
   sudo yum install cairo-devel pango-devel gdk-pixbuf2-devel libffi-devel
   ```

2. **Pandoc not found**
   ```bash
   # Ubuntu/Debian
   sudo apt-get install pandoc
   
   # CentOS/RHEL
   sudo yum install pandoc
   ```

3. **Permission denied**
   ```bash
   sudo chown -R $USER:$USER /path/to/DOCX_PDF_API
   ```

4. **Port already in use**
   ```bash
   sudo lsof -i :8000
   sudo kill -9 <PID>
   ```

### Performance Optimization

1. **Increase file upload limits** in Nginx:
   ```nginx
   client_max_body_size 50M;
   ```

2. **Enable gzip compression**:
   ```nginx
   gzip on;
   gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
   ```

3. **Set proper timeouts**:
   ```nginx
   proxy_read_timeout 300s;
   proxy_connect_timeout 75s;
   ```

## Security

### HTTPS Setup
```bash
# Install Certbot
sudo apt-get install certbot python3-certbot-nginx

# Get SSL certificate
sudo certbot --nginx -d your-domain.com
```

### Firewall Configuration
```bash
sudo ufw allow 22    # SSH
sudo ufw allow 80    # HTTP
sudo ufw allow 443   # HTTPS
sudo ufw enable
```

## Dependencies

### Python Packages
- fastapi>=0.104.0
- uvicorn[standard]>=0.24.0
- pydantic>=2.0.0
- reportlab>=4.0.0
- weasyprint>=60.0
- pypandoc>=1.11
- python-docx>=0.8.11
- html2docx>=0.0.6
- markdown-it-py>=3.0.0
- mdit-py-plugins>=0.4.0
- pygments>=2.15.0
- pillow>=10.0.0
- cairosvg>=2.8.0
- cairocffi>=1.7.0
- requests>=2.31.0
- psutil>=5.9.0

### System Dependencies
- Python 3.8+
- Cairo development libraries
- Pango development libraries
- GDK-PixBuf development libraries
- libffi development libraries
- Pandoc (optional, for DOCX generation)

## License

This project is licensed under the MIT License.

## Support

For issues and questions:
1. Check the troubleshooting section
2. Run the compatibility test: `python test_linux_compatibility.py`
3. Check the health endpoint: `curl http://localhost:8000/health`
4. Review the logs for error messages

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test on Linux systems
5. Submit a pull request

## Changelog

### Version 1.0.0
- Initial release with high-resolution Mermaid support
- Linux compatibility for major distributions
- Docker support
- Health monitoring
- Production deployment guides
