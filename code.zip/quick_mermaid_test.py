#!/usr/bin/env python3
"""Quick test to verify mermaid-cli works"""
import subprocess
import tempfile
import os

# Simple mermaid diagram
mermaid_code = """flowchart TD
    A[Start] --> B[Process]
    B --> C[End]
"""

print("Testing mermaid-cli (mmdc)...")
print("-" * 60)

# Create temp files
with tempfile.NamedTemporaryFile(mode='w', suffix='.mmd', delete=False) as mmd_file:
    mmd_file.write(mermaid_code)
    mmd_path = mmd_file.name

with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as png_file:
    png_path = png_file.name

try:
    # Run mmdc command
    cmd = ['mmdc', '-i', mmd_path, '-o', png_path,
           '--width', '2400', '--height', '1800',
           '--backgroundColor', 'white',
           '--scale', '3']

    print(f"Running command: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

    if result.returncode == 0:
        if os.path.exists(png_path) and os.path.getsize(png_path) > 0:
            print(f"✓ SUCCESS: Mermaid diagram rendered!")
            print(f"  Output file: {png_path}")
            print(f"  File size: {os.path.getsize(png_path)} bytes")
            print(f"\nKeeping output file for inspection: {png_path}")
        else:
            print(f"✗ FAIL: Output file not created or empty")
    else:
        print(f"✗ FAIL: mmdc returned error code {result.returncode}")
        print(f"STDERR: {result.stderr}")

except FileNotFoundError:
    print("✗ FAIL: mmdc command not found")
    print("Install with: npm install -g @mermaid-js/mermaid-cli")
except subprocess.TimeoutExpired:
    print("✗ FAIL: Command timed out")
except Exception as e:
    print(f"✗ FAIL: {e}")
finally:
    # Clean up input file only
    try:
        if os.path.exists(mmd_path):
            os.remove(mmd_path)
    except:
        pass

print("-" * 60)
