#!/bin/bash
# Linux installation script for DOCX_PDF_API with high-resolution Mermaid support

set -e

echo "Installing DOCX_PDF_API dependencies for Linux..."

# Update package manager
if command -v apt-get &> /dev/null; then
    echo "Detected Ubuntu/Debian system"
    sudo apt-get update
    sudo apt-get install -y python3-pip python3-venv build-essential
    
    # Install Cairo system dependencies
    sudo apt-get install -y libcairo2-dev libpango1.0-dev libgdk-pixbuf2.0-dev libffi-dev shared-mime-info
    
    # Install additional dependencies for WeasyPrint (optional)
    sudo apt-get install -y libpango1.0-0 libharfbuzz0b libpangoft2-1.0-0
    
elif command -v yum &> /dev/null; then
    echo "Detected CentOS/RHEL system"
    sudo yum update -y
    sudo yum install -y python3-pip python3-venv gcc gcc-c++ make
    
    # Install Cairo system dependencies
    sudo yum install -y cairo-devel pango-devel gdk-pixbuf2-devel libffi-devel
    
    # Install additional dependencies for WeasyPrint (optional)
    sudo yum install -y pango harfbuzz
    
elif command -v dnf &> /dev/null; then
    echo "Detected Fedora system"
    sudo dnf update -y
    sudo dnf install -y python3-pip python3-venv gcc gcc-c++ make
    
    # Install Cairo system dependencies
    sudo dnf install -y cairo-devel pango-devel gdk-pixbuf2-devel libffi-devel
    
    # Install additional dependencies for WeasyPrint (optional)
    sudo dnf install -y pango harfbuzz
    
else
    echo "Unsupported Linux distribution. Please install the following manually:"
    echo "- Python 3.8+ with pip"
    echo "- Cairo development libraries (libcairo2-dev or cairo-devel)"
    echo "- Pango development libraries (libpango1.0-dev or pango-devel)"
    echo "- GDK-PixBuf development libraries"
    echo "- libffi development libraries"
    exit 1
fi

# Create virtual environment
echo "Creating Python virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Upgrade pip
pip install --upgrade pip

# Install Python dependencies
echo "Installing Python packages..."
pip install -r requirements.txt

# Test Cairo installation
echo "Testing Cairo installation..."
python3 -c "
try:
    import cairosvg
    print('✓ cairosvg installed successfully')
except ImportError as e:
    print('✗ cairosvg installation failed:', e)
    exit(1)

try:
    import cairocffi
    print('✓ cairocffi installed successfully')
except ImportError as e:
    print('✗ cairocffi installation failed:', e)
    exit(1)

print('✓ All dependencies installed successfully!')
"

echo ""
echo "Installation complete!"
echo ""
echo "To start the server:"
echo "1. Activate the virtual environment: source venv/bin/activate"
echo "2. Start the server: python -m uvicorn api:app --host 0.0.0.0 --port 8000"
echo ""
echo "The API will be available at: http://your-server-ip:8000"
echo ""
echo "Features enabled:"
echo "- High-resolution Mermaid diagram rendering"
echo "- PDF generation with ReportLab"
echo "- DOCX generation with Pandoc + python-docx fallback"
echo "- SVG to PNG conversion for crisp text"
